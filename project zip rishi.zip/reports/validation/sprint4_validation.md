# Sprint 4 - Validation and visualisation

## What we did

1. **Completed model improvements** - froze the best Sprint 2.2 configs (Random Forest + HistGradientBoosting + Ensemble soft vote) instead of re-searching the full 24-run grid.
2. **Different dataset** - rebuilt the same feature recipe with **QQQ** next-day Up/Down as the target (Nasdaq-100 ETF). Mood features stay shared; price features come from QQQ.
3. **Same protocol** - chronological 80/20 train/test, calibration threshold tuning, SMOTE only where the frozen config used it.
4. **Side-by-side** - GSPC vs QQQ metrics in CSV + PNG charts.

## Results (accuracy)

| Model | GSPC (recheck) | QQQ (validation) | Δ accuracy |
|-------|----------------|------------------|------------|
| Random Forest | 49.0% | 50.2% | +1.2% |
| HistGradientBoosting | 50.2% | 53.8% | +3.6% |
| Ensemble soft vote | 51.8% | 51.8% | +0.0% |

## How to read this

- If QQQ scores stay close to GSPC, the model generalises beyond one index.
- If QQQ drops a lot, the GSPC result was more market-specific.
- Modest accuracy (~50–60%) is expected for next-day direction; look at balanced accuracy and F1 too.

## Files

- `validation_side_by_side.csv` - long table (dataset × model × metrics)
- `previous_vs_validation.csv` - wide GSPC vs QQQ deltas
- `validation_side_by_side.png` - grouped bars
- `validation_accuracy_compare.png` - accuracy focus chart
