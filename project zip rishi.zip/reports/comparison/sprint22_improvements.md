# Sprint 2.2: what we changed (simple bullets)

Full story in plain words: docs/05_sprint_22_changes_simple.md

## Data

- More news: Yahoo tickers plus RSS feeds; headlines saved in an archive file.
- Daily news file merged from the archive (more days when RSS has dates).
- Daily put/call from CBOE PCCE (not one flat snapshot).
- New columns: gap_ret, ret_lag2, qqq_rel_mom5, breadth_change, plus vol,
  range, VIX vs MA, put/call PCCE, and smoothed news.

## Training tricks

- Class weights; LogReg C tuning; probability cutoff tuned on calibration days.
- HistGradientBoosting, LightGBM, RF on price only and price plus mood.
- Ensemble: average LogReg + RF + HistGradientBoosting probabilities.

## Best honest runs (test set, recall under 92%)

- Best accuracy: LightGBM (price only) -> accuracy 0.538, balanced acc 0.522, F1 0.620, ROC AUC 0.495.
- Best F1: Logistic Regression -> F1 0.674, accuracy 0.510.
- Best balanced accuracy: LightGBM -> 0.522.
- Ensemble soft vote -> accuracy 0.510, F1 0.628, balanced acc 0.483.

## Versus Sprint 2.1

- Baseline accuracy 0.522, F1 0.659.
- 2.2 best honest accuracy 0.538 (change +0.016).

## Note

Daily direction stays noisy. We report balanced accuracy so scores are not inflated
by guessing Up every day.
